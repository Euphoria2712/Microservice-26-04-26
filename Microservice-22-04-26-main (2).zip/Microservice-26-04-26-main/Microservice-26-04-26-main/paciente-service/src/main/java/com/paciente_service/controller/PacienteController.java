package com.paciente_service.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.paciente_service.model.Paciente;
import com.paciente_service.service.PacienteService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;


@RestController
@RequestMapping("/pacientes")
public class PacienteController {

    @Autowired
    private PacienteService pacienteService;

    @PostMapping("actualizar/{id}")
    public ResponseEntity<Paciente> actualizarPaciente(
        @PathVariable Long id,
        @RequestBody Paciente pacienteActualizado
    ){
        
        try { 
            Paciente pacienteListo = pacienteService.updatePaciente(id, null)

    }
    }
    
    

}
