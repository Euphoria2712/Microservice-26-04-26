package com.paciente_service.service;

import com.paciente_service.dto.PacienteDTO;
import com.paciente_service.model.Paciente;
import com.paciente_service.repository.PacienteRepository;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;

import com.paciente_service.controller.*;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PacienteService {

    private final PacienteRepository pacienteRepository;

    @Transactional(readOnly = true)
    public List<PacienteDTO> get() {
        return pacienteRepository.findAll()
                .stream()
                .sorted((p1, p2) -> p1.getNombre().compareToIgnoreCase(p2.getNombre()))
                .map(this::convertirDTO)
                .collect(Collectors.toList());
    }

    private PacienteDTO convertirDTO(Paciente paciente) {
        return new PacienteDTO(
                paciente.getNombre(),
                paciente.getDocumento(),
                paciente.getFechaNacimiento());
    }

    @Transactional
    public PacienteDTO updatePaciente(Long id, PacienteDTO dto) {

        Paciente pacienteExistente = pacienteRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Paciente no encontrado con el id: " + id));

        if (pacienteExistente.getDocumento().equals(dto.getDocumento()) &&
                pacienteRepository.exiexistsByDocumento(dto.getDocumento())) {
            throw new RuntimeException("Ya existe un paciente con ese documento: " + dto.getDocumento());
        }

        pacienteExistente.setNombre(dto.getNombre());
        pacienteExistente.setDocumento(dto.getDocumento());
        pacienteExistente.setFechaNacimiento(dto.getFechaNacimiento());
        return dto;

    }

    @Transactional
    public PacienteDTO deletedPacienteDTO(Long id){
        Paciente paciente = pacienteRepository.findById(id)
        .orElseThrow(() ->  new EntityNotFoundException("Paciente no encontrado con el id: "+ id));

        pacienteRepository.delete(paciente);

        return convertirDTO(paciente);
    }
}
